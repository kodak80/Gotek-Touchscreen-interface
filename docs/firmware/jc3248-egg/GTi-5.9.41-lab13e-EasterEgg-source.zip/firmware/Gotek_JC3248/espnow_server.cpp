// espnow_server.cpp — Waveshare side
// ESP-NOW: pairing and control signals only
// WiFi TCP: disk data transfer (reliable, fast)

#include "espnow_server.h"
#include <Arduino.h>
#include "ESP32_NOW.h"
#include "WiFi.h"
#include <esp_mac.h>
#include <SD_MMC.h>
#include <WiFiClient.h>
#include <ESPmDNS.h>   // home-WiFi transport: resolve the dongle's gotek.local

#define ESPNOW_CHANNEL 6

// ---------- State ----------
volatile bool g_espnow_paired                = false;
volatile bool g_espnow_xiao_ready            = false;
volatile bool g_espnow_xiao_done             = false;
volatile bool g_espnow_xiao_error            = false;
volatile bool g_espnow_link_just_established = false;
volatile uint32_t g_espnow_xiao_last_seen    = 0;
volatile bool     g_dongle_loaded            = false;   // v5.7.x: load-state heartbeat
volatile uint32_t g_dongle_load_id           = 0;
volatile uint32_t g_dongle_img_size          = 0;

bool espnowXiaoOnline() {
  if (!g_espnow_paired) return false;
  if (g_espnow_xiao_last_seen == 0) return false;
  return (millis() - g_espnow_xiao_last_seen) < 30000; // 30s timeout
}

// ── Save writeback state (v4.8.0) ──
volatile uint8_t  g_espnow_dongle_caps  = 0;
volatile uint8_t  g_espnow_dongle_board = 0;
volatile uint32_t g_espnow_load_id      = 0;
volatile bool     g_espnow_dirty        = false;
volatile uint32_t g_espnow_dirty_loadid = 0;
volatile uint16_t g_espnow_dirty_count  = 0;
volatile uint32_t g_espnow_dirty_size   = 0;
// CRC32 (IEEE, bitwise — identical implementation on the dongle side)
static uint32_t crc32sw(uint32_t crc, const uint8_t* p, size_t n) {
  crc = ~crc;
  while (n--) { crc ^= *p++; for (int k = 0; k < 8; k++) crc = (crc >> 1) ^ (0xEDB88320UL & (uint32_t)(-(int32_t)(crc & 1))); }
  return ~crc;
}

static uint8_t _xiao_mac[6] = {0};
static String  _xiao_ip     = "";

// ---------- Multi-dongle scan (Path 1: collect-all, pick one into active slot) ----------
#define MAX_SCANNED 64   // hard ceiling (array size); runtime cap set from CONFIG.TXT CAP=
struct ScannedDongle { uint8_t mac[6]; char ip[16]; };
static ScannedDongle _scanned[MAX_SCANNED];
static int  _scanned_count = 0;
static volatile bool _scan_mode = false;
static int _scanCap = 32;   // runtime cap (CONFIG.TXT CAP=), clamped to MAX_SCANNED
void espnowSetScanCap(int n){ if(n<1)n=1; if(n>MAX_SCANNED)n=MAX_SCANNED; _scanCap=n; }

// ---------- Packet structs ----------
#pragma pack(push,1)
struct PktHello  { uint8_t type; uint8_t mac[6]; char ip[16]; uint8_t pad[227]; };
struct PktSimple { uint8_t type; uint8_t pad[249]; };
struct PktEject  { uint8_t type; uint8_t pad[249]; };
#pragma pack(pop)

// ---------- Forward declare ----------
static void handleIncoming(const uint8_t* data, int len);

// ---------- Peer class ----------
class GotekPeer : public ESP_NOW_Peer {
public:
  GotekPeer(const uint8_t* mac, uint8_t ch, wifi_interface_t iface, const uint8_t* lmk)
    : ESP_NOW_Peer(mac, ch, iface, lmk) {}
  ~GotekPeer() { remove(); }
  bool add_peer() { return add(); }
  bool send_pkt(const uint8_t* d, size_t l) { return send(d, l); }
  void onReceive(const uint8_t* d, size_t l, bool b) override { handleIncoming(d, (int)l); }
  void onSent(bool) override {}
};

static GotekPeer* _bcastPeer = nullptr;
static GotekPeer* _xiaoPeer  = nullptr;

// ---------- Incoming handler ----------
static void handleIncoming(const uint8_t* data, int len) {
  if (len < 1) return;
  uint8_t type = data[0];

  if (type == PKT_PAIR_REPLY) {
    const PktHello* p = (const PktHello*)data;

    // Scan mode: collect every distinct dongle, don't commit yet
    if (_scan_mode) {
      for (int i=0;i<_scanned_count;i++)
        if (memcmp(_scanned[i].mac, p->mac, 6)==0) { g_espnow_xiao_last_seen=millis(); return; } // already have it
      if (_scanned_count < _scanCap) {
        memcpy(_scanned[_scanned_count].mac, p->mac, 6);
        strncpy(_scanned[_scanned_count].ip, p->ip, 15);
        _scanned[_scanned_count].ip[15]=0;
        _scanned_count++;
        g_espnow_xiao_last_seen = millis();
      }
      return;
    }

    memcpy(_xiao_mac, p->mac, 6);
    _xiao_ip = String(p->ip);
    g_espnow_paired = true;
    g_espnow_link_just_established = true;
    g_espnow_xiao_last_seen = millis();
    g_espnow_dongle_caps  = p->pad[0];   // v3.2.0+ dongles advertise the save protocol here
    g_espnow_dongle_board = p->pad[1];   // v5.x: 1 = HD-capable dongle (XIAO 8MB); 0 = DD-only / old dongle

    // Register XIAO as direct peer
    if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
    _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
    if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }

    // Save to CONFIG.TXT
    char macStr[18];
    snprintf(macStr, sizeof(macStr), "%02X:%02X:%02X:%02X:%02X:%02X",
             _xiao_mac[0],_xiao_mac[1],_xiao_mac[2],
             _xiao_mac[3],_xiao_mac[4],_xiao_mac[5]);
    String lines = ""; bool written = false;
    File fr = SD_MMC.open("/CONFIG.TXT", FILE_READ);
    if (fr) {
      while (fr.available()) {
        String line = fr.readStringUntil('\n'); line.trim();
        if (line.startsWith("XIAO_MAC=")) { lines += "XIAO_MAC=" + String(macStr) + "\n"; written = true; }
        else if (line.startsWith("XIAO_IP=")) { lines += "XIAO_IP=" + _xiao_ip + "\n"; }
        else { lines += line + "\n"; }
      }
      fr.close();
    }
    if (!written) lines += "XIAO_MAC=" + String(macStr) + "\n";
    File fw = SD_MMC.open("/CONFIG.TXT", FILE_WRITE);
    if (fw) { fw.print(lines); fw.close(); }
    Serial.printf("[NOW] Paired: MAC=%s IP=%s\n", macStr, _xiao_ip.c_str());
    return;
  }

  if (type == PKT_XIAO_READY) { g_espnow_xiao_last_seen = millis(); g_espnow_xiao_ready = true; return; }
  if (type == PKT_XIAO_DONE)  { g_espnow_xiao_last_seen = millis(); g_espnow_xiao_done = true; g_espnow_xiao_error = false; return; }
  if (type == PKT_XIAO_ERROR) { g_espnow_xiao_last_seen = millis(); g_espnow_xiao_error = true; g_espnow_xiao_done = false; return; }

  if (type == PKT_XIAO_DIRTY && len >= 16) {   // v4.8.0: dongle has settled unsaved writes
    g_espnow_xiao_last_seen = millis();        // beacon doubles as a keepalive
    g_espnow_dirty_loadid = (uint32_t)data[1] | ((uint32_t)data[2]<<8) | ((uint32_t)data[3]<<16) | ((uint32_t)data[4]<<24);
    g_espnow_dirty_count  = (uint16_t)data[5] | ((uint16_t)data[6]<<8);
    g_espnow_dirty_size   = (uint32_t)data[7] | ((uint32_t)data[8]<<8) | ((uint32_t)data[9]<<16) | ((uint32_t)data[10]<<24);
    g_espnow_dirty = (g_espnow_dirty_count > 0);
    if (!g_espnow_dongle_caps) g_espnow_dongle_caps = 1;   // beacon itself proves capability
    return;
  }

  if (type == PKT_XIAO_STATUS && len >= 10) {   // v5.7.x: load-state heartbeat from the dongle
    g_espnow_xiao_last_seen = millis();
    g_dongle_loaded   = data[1] ? true : false;
    g_dongle_load_id  = (uint32_t)data[2] | ((uint32_t)data[3]<<8) | ((uint32_t)data[4]<<16) | ((uint32_t)data[5]<<24);
    g_dongle_img_size = (uint32_t)data[6] | ((uint32_t)data[7]<<8) | ((uint32_t)data[8]<<16) | ((uint32_t)data[9]<<24);
    if (!g_espnow_dongle_caps) g_espnow_dongle_caps = 1;
    return;
  }
}

static void onNewPeer(const esp_now_recv_info_t* info, const uint8_t* data, int len, void* arg) {
  handleIncoming(data, len);
}

// ---------- Load saved config ----------
static void loadConfig() {
  File f = SD_MMC.open("/CONFIG.TXT", FILE_READ);
  if (!f) return;
  while (f.available()) {
    String line = f.readStringUntil('\n'); line.trim();
    if (line.startsWith("#")) continue;
    if (line.startsWith("XIAO_MAC=")) {
      String mac = line.substring(9);
      sscanf(mac.c_str(), "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
             &_xiao_mac[0],&_xiao_mac[1],&_xiao_mac[2],
             &_xiao_mac[3],&_xiao_mac[4],&_xiao_mac[5]);
      bool isZero = true;
      for (int i=0;i<6;i++) if(_xiao_mac[i]) { isZero=false; break; }
      if (!isZero) g_espnow_paired = true;
    }
    if (line.startsWith("XIAO_IP=")) _xiao_ip = line.substring(8);
  }
  f.close();
  if (g_espnow_paired) Serial.printf("[NOW] Loaded config: IP=%s\n", _xiao_ip.c_str());
}

// ---------- API ----------
void espnowBegin() {
  if(_bcastPeer){ delete _bcastPeer; _bcastPeer=nullptr; }   // 5.9.17: idempotent so a live re-init is safe
  if(_xiaoPeer){ delete _xiaoPeer; _xiaoPeer=nullptr; }
  ESP_NOW.end();
  // Use WIFI_AP_STA — AP mode needed for Waveshare to connect to XIAO's AP later
  WiFi.mode(WIFI_AP_STA);
  WiFi.setChannel(ESPNOW_CHANNEL);
  while (!WiFi.STA.started()) delay(100);

  if (!ESP_NOW.begin()) { Serial.println("[NOW] begin FAILED"); return; }
  Serial.println("[NOW] begin OK");

  ESP_NOW.onNewPeer(onNewPeer, nullptr);

  _bcastPeer = new GotekPeer(ESP_NOW.BROADCAST_ADDR, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (!_bcastPeer->add_peer()) { delete _bcastPeer; _bcastPeer = nullptr; }

  loadConfig();

  if (g_espnow_paired) {
    _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
    if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }
    Serial.println("[NOW] Restored XIAO peer");
  }
}

// 5.9.17: stop ESP-NOW cleanly so MODE can switch away from it without a reboot.
void espnowStop() {
  ESP_NOW.end();
  if(_bcastPeer){ delete _bcastPeer; _bcastPeer=nullptr; }
  if(_xiaoPeer){ delete _xiaoPeer; _xiaoPeer=nullptr; }
}

void espnowBroadcastHello() {
  if (!_bcastPeer) return;
  PktHello pkt = {};
  pkt.type = PKT_PAIR_HELLO;
  WiFi.macAddress(pkt.mac);
  _bcastPeer->send_pkt((uint8_t*)&pkt, sizeof(pkt));
}

// ---------- Multi-dongle scan API ----------
void espnowScanBegin() { _scanned_count = 0; _scan_mode = true; }
void espnowScanEnd()   { _scan_mode = false; }
int  espnowScanCount() { return _scanned_count; }

String espnowScanGetMac(int i) {
  if (i<0 || i>=_scanned_count) return "";
  char buf[18];
  snprintf(buf,sizeof(buf),"%02X:%02X:%02X:%02X:%02X:%02X",
           _scanned[i].mac[0],_scanned[i].mac[1],_scanned[i].mac[2],
           _scanned[i].mac[3],_scanned[i].mac[4],_scanned[i].mac[5]);
  return String(buf);
}

// Commit a scanned dongle as the active target (copies into the proven single slot)
bool espnowScanSelect(int i) {
  if (i<0 || i>=_scanned_count) return false;
  _scan_mode = false;
  memcpy(_xiao_mac, _scanned[i].mac, 6);
  _xiao_ip = String(_scanned[i].ip);
  g_espnow_paired = true;
  g_espnow_link_just_established = true;
  g_espnow_xiao_last_seen = millis();

  // Register as direct peer (same as the original pairing path)
  if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
  _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }

  // Persist active dongle to CONFIG.TXT (same keys as original pairing)
  char macStr[18];
  snprintf(macStr,sizeof(macStr),"%02X:%02X:%02X:%02X:%02X:%02X",
           _xiao_mac[0],_xiao_mac[1],_xiao_mac[2],_xiao_mac[3],_xiao_mac[4],_xiao_mac[5]);
  String lines=""; bool w1=false,w2=false;
  File fr=SD_MMC.open("/CONFIG.TXT",FILE_READ);
  if(fr){while(fr.available()){String line=fr.readStringUntil('\n');line.trim();
    if(line.startsWith("XIAO_MAC=")){lines+="XIAO_MAC="+String(macStr)+"\n";w1=true;}
    else if(line.startsWith("XIAO_IP=")){lines+="XIAO_IP="+_xiao_ip+"\n";w2=true;}
    else lines+=line+"\n";}fr.close();}
  if(!w1)lines+="XIAO_MAC="+String(macStr)+"\n";
  if(!w2)lines+="XIAO_IP="+_xiao_ip+"\n";
  File fw=SD_MMC.open("/CONFIG.TXT",FILE_WRITE);
  if(fw){fw.print(lines);fw.close();}
  Serial.printf("[NOW] Selected dongle %d: %s\n", i, macStr);
  return true;
}

// ── Paired-dongle management (v5.7): delete = unpair-over-air + forget locally ──
// Raw MAC of a scanned dongle (for a targeted unpair).
void espnowScanMacBytes(int i, uint8_t* out){
  if(i>=0 && i<_scanned_count) memcpy(out, _scanned[i].mac, 6);
}
// Tell ONE dongle (unicast) to drop THIS GTi from its owner list. Sent 3x (ESP-NOW is lossy).
void espnowSendUnpair(const uint8_t* mac){
  PktHello pkt = {}; pkt.type = PKT_UNPAIR; WiFi.macAddress(pkt.mac);
  if (_xiaoPeer && memcmp(_xiao_mac, mac, 6)==0) {
    for(int k=0;k<3;k++){ _xiaoPeer->send_pkt((uint8_t*)&pkt, sizeof(pkt)); delay(30); }
    return;
  }
  GotekPeer* tp = new GotekPeer(mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (tp->add_peer()) for(int k=0;k<3;k++){ tp->send_pkt((uint8_t*)&pkt, sizeof(pkt)); delay(30); }
  delete tp;
}
// Webby: tell ONE dongle (unicast) to LOCK to this GTi (enroll me as sole owner). Sent 3x.
void espnowSendLock(const uint8_t* mac){
  PktHello pkt = {}; pkt.type = PKT_LOCK; WiFi.macAddress(pkt.mac);
  if (_xiaoPeer && memcmp(_xiao_mac, mac, 6)==0) {
    for(int k=0;k<3;k++){ _xiaoPeer->send_pkt((uint8_t*)&pkt, sizeof(pkt)); delay(30); }
    return;
  }
  GotekPeer* tp = new GotekPeer(mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (tp->add_peer()) for(int k=0;k<3;k++){ tp->send_pkt((uint8_t*)&pkt, sizeof(pkt)); delay(30); }
  delete tp;
}
// Webby: tell ONE dongle (unicast) to UNLOCK (clear owners -> open to any GTi). Sent 3x.
void espnowSendUnlock(const uint8_t* mac){
  PktHello pkt = {}; pkt.type = PKT_UNLOCK; WiFi.macAddress(pkt.mac);
  if (_xiaoPeer && memcmp(_xiao_mac, mac, 6)==0) {
    for(int k=0;k<3;k++){ _xiaoPeer->send_pkt((uint8_t*)&pkt, sizeof(pkt)); delay(30); }
    return;
  }
  GotekPeer* tp = new GotekPeer(mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (tp->add_peer()) for(int k=0;k<3;k++){ tp->send_pkt((uint8_t*)&pkt, sizeof(pkt)); delay(30); }
  delete tp;
}
// If we're forgetting the currently-active dongle, clear the local pairing + strip CONFIG.TXT.
void espnowForgetActive(const uint8_t* mac){
  if (memcmp(_xiao_mac, mac, 6)!=0) return;
  g_espnow_paired = false; memset(_xiao_mac, 0, 6); _xiao_ip = "";
  if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
  String lines=""; File fr=SD_MMC.open("/CONFIG.TXT",FILE_READ);
  if(fr){ while(fr.available()){ String line=fr.readStringUntil('\n'); line.trim();
    if(line.startsWith("XIAO_MAC=")||line.startsWith("XIAO_IP=")) continue; lines+=line+"\n"; } fr.close(); }
  File fw=SD_MMC.open("/CONFIG.TXT",FILE_WRITE); if(fw){ fw.print(lines); fw.close(); }
}

bool   espnowIsPaired()       { return g_espnow_paired; }
String espnowGetSSIDLabel()   { return "WiFi+NOW"; }
String espnowGetXiaoMac() {
  char buf[18];
  snprintf(buf,sizeof(buf),"%02X:%02X:%02X:%02X:%02X:%02X",
           _xiao_mac[0],_xiao_mac[1],_xiao_mac[2],
           _xiao_mac[3],_xiao_mac[4],_xiao_mac[5]);
  return String(buf);
}

bool espnowSendNotify(const String& name, const String& mode, uint32_t size) {
  // For WiFi TCP approach, notify isn't needed — we just connect and send
  // But we signal XIAO to be ready
  g_espnow_xiao_ready = false;
  g_espnow_xiao_done  = false;
  g_espnow_xiao_error = false;
  return true; // proceed straight to sendDisk
}

// ── Wireless DSK fix (1.6.3) ────────────────────────────────────────────────
// The dongle historically named EVERY flung image DISK.ADF, so a CPC/Spectrum
// .dsk mounted as an ADF and FlashFloppy threw Error 34. The panel now sends
// the real filename+extension via the CMD_SET_NAME escape on its own short TCP
// connection just before the disk fling; the dongle builds the FAT12 root from
// that extension. Backward compatible: a dongle too old to know CMD_SET_NAME
// simply NAKs the escape and the fling still lands as DISK.ADF (old behaviour).
#ifndef CMD_SET_NAME
#define CMD_SET_NAME 0x06
#endif
static String g_fling_name = "";
void espnowSetFlingName(const String& nameWithExt){
  g_fling_name = nameWithExt.length() ? nameWithExt : String("DISK.ADF");
}
// Open a short TCP connection to the dongle and set the name+ext for the NEXT
// fling. Best-effort: any failure is silently ignored (fling falls back to ADF).
static void tcpSendSetName(const char* ip){
  if (g_fling_name.length() == 0) return;
  WiFiClient c;
  if (!c.connect(ip, DONGLE_TCP_PORT)) return;
  uint8_t esc[5] = {0xFF,0xFF,0xFF,0xFF, CMD_SET_NAME};
  c.write(esc, 5);
  uint8_t L = (uint8_t)(g_fling_name.length() > 128 ? 128 : g_fling_name.length());
  c.write(&L, 1);
  c.write((const uint8_t*)g_fling_name.c_str(), L);
  uint32_t t0 = millis();
  while (!c.available() && millis()-t0 < 1000) delay(5);
  if (c.available()) c.read();   // consume the 0x01/0x00 ack
  c.stop();
  delay(20);
}

static bool sendDiskCore(const uint8_t* mac, const char* ipc, uint32_t size, uint32_t connectTimeoutMs) {
  String ip = String(ipc);
  Serial.printf("[TCP] Connecting to XIAO at %s:%d\n", ip.c_str(), DONGLE_TCP_PORT);

  // Stop ESP-NOW before switching WiFi mode
  ESP_NOW.end();
  delay(100);

  // Switch to pure STA mode to connect to XIAO's AP
  WiFi.mode(WIFI_STA);
  delay(100);
  // Multicast hardening: drop any sticky/auto association to a previous same-SSID dongle,
  // so WiFi.begin() targets THIS BSSID instead of silently reconnecting to the last one.
  WiFi.persistent(false);
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, true);   // keep radio on, erase saved AP so it can't auto-reconnect
  delay(200);
  // Target the specific dongle by BSSID (all dongles share SSID "GotekXIAO" on channel 6).
  // Without the BSSID, with multiple dongles powered on we'd associate to a random one.
  WiFi.begin(DONGLE_AP_SSID, DONGLE_AP_PASS, ESPNOW_CHANNEL, (uint8_t*)mac);

  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis()-t0 < connectTimeoutMs) {
    delay(200);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[TCP] WiFi connect failed — restarting ESP-NOW");
    WiFi.disconnect();
    delay(200);
    WiFi.mode(WIFI_AP_STA);
    WiFi.setChannel(ESPNOW_CHANNEL);
    while (!WiFi.STA.started()) delay(100);
    ESP_NOW.begin();
    ESP_NOW.onNewPeer(onNewPeer, nullptr);
    if (_bcastPeer) { delete _bcastPeer; _bcastPeer = nullptr; }
    _bcastPeer = new GotekPeer(ESP_NOW.BROADCAST_ADDR, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
    if (!_bcastPeer->add_peer()) { delete _bcastPeer; _bcastPeer = nullptr; }
    if (g_espnow_paired) {
      if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
      _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
      if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }
    }
    return false;
  }
  Serial.printf("[TCP] WiFi connected. IP: %s\n", WiFi.localIP().toString().c_str());

  // 1.6.3: tell the dongle the real filename+ext before the disk fling
  tcpSendSetName(ip.c_str());

  // Connect TCP
  WiFiClient client;
  if (!client.connect(ip.c_str(), DONGLE_TCP_PORT)) {
    Serial.println("[TCP] TCP connect failed");
    WiFi.disconnect();
    delay(100);
    WiFi.mode(WIFI_AP_STA);
    WiFi.setChannel(ESPNOW_CHANNEL);
    return false;
  }
  Serial.printf("[TCP] Connected to XIAO TCP server\n");

  // Protocol: send 4-byte size (big endian), then raw data
  uint8_t* src = g_disk + ESPNOW_DATA_LBA * ESPNOW_SECTOR_SIZE;

  // Send size header
  uint8_t hdr[4] = {
    (uint8_t)(size >> 24), (uint8_t)(size >> 16),
    (uint8_t)(size >> 8),  (uint8_t)(size)
  };
  client.write(hdr, 4);

  // Send data in 4KB chunks
  uint32_t sent = 0;
  const size_t BUF = 4096;
  while (sent < size) {
    size_t n = min((uint32_t)BUF, size - sent);
    size_t written = client.write(src + sent, n);
    if (written == 0) { Serial.println("[TCP] Write error"); break; }
    sent += written;
  }
  client.clear();
  Serial.printf("[TCP] Sent %lu bytes\n", (unsigned long)sent);

  // Wait for XIAO to confirm (single byte: 0x01=OK, 0x00=ERROR)
  t0 = millis();
  while (!client.available() && millis()-t0 < 10000) delay(10);
  bool ok = false;
  if (client.available()) {
    uint8_t resp = client.read();
    ok = (resp == 0x01);
    Serial.printf("[TCP] XIAO response: 0x%02X (%s)\n", resp, ok?"OK":"ERROR");
    if (ok) {
      // v3.2.0 dongles append a 4-byte load_id after the ack (old dongles don't —
      // short wait, then give up and leave it 0, which disables save mapping)
      uint32_t tid = millis(); uint8_t lid[4]; int got = 0;
      while (got < 4 && millis()-tid < 300) {
        if (client.available()) lid[got++] = client.read(); else delay(5);
      }
      g_espnow_load_id = (got == 4)
        ? ((uint32_t)lid[0] | ((uint32_t)lid[1]<<8) | ((uint32_t)lid[2]<<16) | ((uint32_t)lid[3]<<24))
        : 0;
      if (got == 4) Serial.printf("[TCP] load_id=%lu\n", (unsigned long)g_espnow_load_id);
    }
  } else {
    Serial.println("[TCP] No response from XIAO");
  }
  client.stop();

  // Restore ESP-NOW
  WiFi.disconnect();
  delay(200);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setChannel(ESPNOW_CHANNEL);
  while (!WiFi.STA.started()) delay(100);
  ESP_NOW.begin();
  ESP_NOW.onNewPeer(onNewPeer, nullptr);
  if (_bcastPeer) { delete _bcastPeer; _bcastPeer = nullptr; }
  _bcastPeer = new GotekPeer(ESP_NOW.BROADCAST_ADDR, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (!_bcastPeer->add_peer()) { delete _bcastPeer; _bcastPeer = nullptr; }
  if (g_espnow_paired) {
    if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
    _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
    if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }
  }
  Serial.println("[NOW] ESP-NOW restored after TCP transfer");

  if (ok) g_espnow_xiao_done = true;
  else    g_espnow_xiao_error = true;
  return ok;
}

// Home-WiFi transport: join the home router (STA/DHCP), resolve the dongle via mDNS
// "gotek.local" (or use the cached ioIp), push the disk over TCP-3333, then restore
// ESP-NOW/AP_STA exactly like sendDiskCore. ioIp receives the resolved IP to persist.
bool espnowSendDiskHome(const String& ssid, const String& pass, String& ioIp, uint32_t size) {
  if (ssid.length() == 0) { g_espnow_xiao_error = true; return false; }
  Serial.printf("[HOME] Joining '%s' to reach the dongle\n", ssid.c_str());
  ESP_NOW.end(); delay(100);
  WiFi.mode(WIFI_STA); delay(100);
  WiFi.persistent(false); WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, true); delay(200);
  WiFi.begin(ssid.c_str(), pass.c_str());
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis()-t0 < 15000) { delay(200); Serial.print("."); }
  Serial.println();

  bool ok = false;
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[HOME] Joined. IP %s\n", WiFi.localIP().toString().c_str());
    String ip = ioIp;                                  // cached IP is the fallback
    if (MDNS.begin("gti-remote")) {
      IPAddress r = MDNS.queryHost("gotekomega", 2500);     // Webby advertises gotekomega.local in WiFi mode
      if ((uint32_t)r != 0) { ip = r.toString(); ioIp = ip; Serial.printf("[HOME] gotek.local -> %s\n", ip.c_str()); }
      MDNS.end();
    }
    if (ip.length() > 0) {
      tcpSendSetName(ip.c_str());   // 1.6.3: real filename+ext for the fling
      WiFiClient client;
      if (client.connect(ip.c_str(), DONGLE_TCP_PORT)) {
        uint8_t* src = g_disk + ESPNOW_DATA_LBA * ESPNOW_SECTOR_SIZE;
        uint8_t hdr[4] = { (uint8_t)(size>>24),(uint8_t)(size>>16),(uint8_t)(size>>8),(uint8_t)size };
        client.write(hdr, 4);
        uint32_t sent = 0; const size_t BUF = 4096;
        while (sent < size) { size_t n = min((uint32_t)BUF, size-sent); size_t w = client.write(src+sent, n); if (!w) break; sent += w; }
        client.clear();
        t0 = millis(); while (!client.available() && millis()-t0 < 10000) delay(10);
        if (client.available()) {
          ok = (client.read() == 0x01);
          if (ok) { uint32_t tid = millis(); uint8_t lid[4]; int got = 0;
            while (got < 4 && millis()-tid < 300) { if (client.available()) lid[got++] = client.read(); else delay(5); }
            g_espnow_load_id = (got == 4) ? ((uint32_t)lid[0]|((uint32_t)lid[1]<<8)|((uint32_t)lid[2]<<16)|((uint32_t)lid[3]<<24)) : 0;
          }
        }
        client.stop();
        Serial.printf("[HOME] sent %lu bytes, ack=%s\n", (unsigned long)sent, ok?"OK":"ERR");
      } else Serial.println("[HOME] TCP connect failed");
    } else Serial.println("[HOME] dongle not found (mDNS gotek.local + no cached IP)");
  } else Serial.println("[HOME] home WiFi join failed");

  // Restore ESP-NOW / AP_STA (same teardown as sendDiskCore)
  WiFi.disconnect(); delay(200);
  WiFi.mode(WIFI_AP_STA); WiFi.setChannel(ESPNOW_CHANNEL);
  while (!WiFi.STA.started()) delay(100);
  ESP_NOW.begin(); ESP_NOW.onNewPeer(onNewPeer, nullptr);
  if (_bcastPeer) { delete _bcastPeer; _bcastPeer = nullptr; }
  _bcastPeer = new GotekPeer(ESP_NOW.BROADCAST_ADDR, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (!_bcastPeer->add_peer()) { delete _bcastPeer; _bcastPeer = nullptr; }
  if (g_espnow_paired) {
    if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
    _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
    if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }
  }
  if (ok) g_espnow_xiao_done = true; else g_espnow_xiao_error = true;
  return ok;
}

// Single paired dongle — unchanged behaviour (15s connect window, learned IP).
bool espnowSendDisk(uint32_t size) {
  return sendDiskCore(_xiao_mac, (_xiao_ip.length() ? _xiao_ip.c_str() : DONGLE_AP_IP), size, 15000);
}
// Multicast fan-out — target one MuCa dongle by MAC; every dongle's AP serves 192.168.4.1.
// Shorter connect window so a powered-off dongle in the group doesn't stall the whole load.
bool espnowSendDiskTo(const uint8_t* mac, uint32_t size) {
  return sendDiskCore(mac, DONGLE_AP_IP, size, 6000);
}

void espnowSendEject() {
  GotekPeer* dst = _xiaoPeer ? _xiaoPeer : _bcastPeer;
  if (!dst) return;
  PktEject pkt = {}; pkt.type = PKT_DISK_EJECT;
  dst->send_pkt((uint8_t*)&pkt, sizeof(pkt));
}

// ── Save writeback fetch (v4.8.0) — "FLING in reverse" ──────────────────────
// Same radio dance as sendDiskCore, but sends the command escape and PULLS the
// dirty sectors. The persist callback runs while the socket is open; only its
// success sends the 0x01 ack that lets the dongle clear its dirty bits.
static bool readFull(WiFiClient& c, uint8_t* buf, uint32_t len, uint32_t timeoutMs) {
  uint32_t got = 0, t0 = millis();
  while (got < len && millis()-t0 < timeoutMs) {
    if (!c.connected() && !c.available()) return false;
    int avail = c.available();
    if (avail <= 0) { delay(1); continue; }
    int rd = c.read(buf+got, min((uint32_t)avail, len-got));
    if (rd > 0) { got += rd; t0 = millis(); }
  }
  return got == len;
}
static void restoreEspNow() {
  WiFi.disconnect();
  delay(200);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setChannel(ESPNOW_CHANNEL);
  while (!WiFi.STA.started()) delay(100);
  ESP_NOW.begin();
  ESP_NOW.onNewPeer(onNewPeer, nullptr);
  if (_bcastPeer) { delete _bcastPeer; _bcastPeer = nullptr; }
  _bcastPeer = new GotekPeer(ESP_NOW.BROADCAST_ADDR, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
  if (!_bcastPeer->add_peer()) { delete _bcastPeer; _bcastPeer = nullptr; }
  if (g_espnow_paired) {
    if (_xiaoPeer) { delete _xiaoPeer; _xiaoPeer = nullptr; }
    _xiaoPeer = new GotekPeer(_xiao_mac, ESPNOW_CHANNEL, WIFI_IF_STA, nullptr);
    if (!_xiaoPeer->add_peer()) { delete _xiaoPeer; _xiaoPeer = nullptr; }
  }
}

bool espnowFetchSave(SavePersistCb persist) {
  if (!g_espnow_paired || !persist) return false;
  String ip = _xiao_ip.length() ? _xiao_ip : String(DONGLE_AP_IP);
  Serial.printf("[SAVE] Fetching dirty sectors from %s\n", ip.c_str());

  ESP_NOW.end();
  delay(100);
  WiFi.mode(WIFI_STA);
  delay(100);
  WiFi.persistent(false);
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, true);
  delay(200);
  WiFi.begin(DONGLE_AP_SSID, DONGLE_AP_PASS, ESPNOW_CHANNEL, (uint8_t*)_xiao_mac);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis()-t0 < 15000) delay(200);
  if (WiFi.status() != WL_CONNECTED) { Serial.println("[SAVE] WiFi join failed"); restoreEspNow(); return false; }

  WiFiClient client;
  bool okAll = false;
  uint8_t* mapBuf = nullptr; uint8_t* packed = nullptr;
  if (client.connect(ip.c_str(), DONGLE_TCP_PORT)) {
    uint8_t esc[5] = {0xFF,0xFF,0xFF,0xFF, 0x01};   // command escape + GET_SAVE
    client.write(esc, 5);
    uint8_t hdr[14];
    if (readFull(client, hdr, 14, 5000) && hdr[0]=='S' && hdr[1]=='V' && hdr[2]=='1') {
      uint32_t loadId  = (uint32_t)hdr[4] | ((uint32_t)hdr[5]<<8) | ((uint32_t)hdr[6]<<16) | ((uint32_t)hdr[7]<<24);
      uint32_t imgSize = (uint32_t)hdr[8] | ((uint32_t)hdr[9]<<8) | ((uint32_t)hdr[10]<<16) | ((uint32_t)hdr[11]<<24);
      uint16_t mapLen  = (uint16_t)hdr[12] | ((uint16_t)hdr[13]<<8);
      if (mapLen > 0 && mapLen <= 256) {
        mapBuf = (uint8_t*)malloc(mapLen);
        if (mapBuf && readFull(client, mapBuf, mapLen, 5000)) {
          uint32_t nSec = 0;
          for (uint32_t i = 0; i < (uint32_t)mapLen*8; i++)
            if ((mapBuf[i>>3]>>(i&7))&1) nSec++;
          Serial.printf("[SAVE] load=%lu img=%lu dirty=%lu\n",
                        (unsigned long)loadId,(unsigned long)imgSize,(unsigned long)nSec);
          bool dataOk = true;
          if (nSec > 0) {
            packed = (uint8_t*)ps_malloc(nSec*512);
            if (!packed) packed = (uint8_t*)malloc(nSec*512);
            dataOk = packed && readFull(client, packed, nSec*512, 30000);
          }
          uint8_t crcb[4];
          if (dataOk && readFull(client, crcb, 4, 5000)) {
            uint32_t crcRx = (uint32_t)crcb[0] | ((uint32_t)crcb[1]<<8) | ((uint32_t)crcb[2]<<16) | ((uint32_t)crcb[3]<<24);
            uint32_t crc = crc32sw(0, mapBuf, mapLen);
            if (nSec > 0) crc = crc32sw(crc, packed, nSec*512);
            if (crc == crcRx) {
              // Persist to SD *before* acking — the ack is the dongle's permission to forget
              bool saved = persist(loadId, imgSize, mapBuf, mapLen, packed, nSec);
              uint8_t ack = saved ? 0x01 : 0x00;
              client.write(&ack, 1);
              client.flush();
              delay(100);
              okAll = saved;
              Serial.printf("[SAVE] %s\n", saved ? "persisted + acked" : "persist FAILED — no ack");
            } else {
              Serial.println("[SAVE] CRC mismatch — no ack, dongle retains");
              uint8_t ack = 0x00; client.write(&ack, 1); client.flush();
            }
          } else Serial.println("[SAVE] short read — no ack, dongle retains");
        }
      }
    } else Serial.println("[SAVE] bad header");
    client.stop();
  } else Serial.println("[SAVE] TCP connect failed");
  if (mapBuf) free(mapBuf);
  if (packed) free(packed);

  restoreEspNow();
  Serial.println("[NOW] ESP-NOW restored after save fetch");
  if (okAll) g_espnow_dirty = false;   // serviced; a fresh beacon re-raises if more arrives
  return okAll;
}
