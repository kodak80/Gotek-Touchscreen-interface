GTi 5.9.41-lab13e (JC3248) - "Easter Egg Edition" - corresponding source
=======================================================================
This archive is the complete source for firmware/jc3248-egg/GTi-JC35-5.9.41-EasterEgg.merged.bin
on the GTi web flasher (https://github.com/mesarim/Gotek-Touchscreen-interface).

Licences
  - firmware/Gotek_JC3248/src/doom/  : PrBoom 2.5.0 via espressif/esp32-doom (085f21b), GNU GPL v2
    or later - see src/doom/COPYING.GPL2, src/doom/AUTHORS, src/doom/README_GTi.md.
  - Because the image links PrBoom in, the firmware image as a whole is distributed under the
    GNU GPL v2. The rest of the GTi source is also MIT-licensed in the repository.
  - DOOM1.WAD (shareware v1.9, MD5 f0cefca49926d00903cf57551d901abe) is id Software's shareware
    game data, not part of this source. It is stored unmodified in the "doom" partition at 0x810000.

Build (what produced the published image)
  Arduino CLI / IDE, esp32 core 3.3.11, libraries JPEGDEC 1.8.4, PNGdec 1.1.6.
  FQBN: esp32:esp32:esp32s3:UploadSpeed=921600,USBMode=default,CDCOnBoot=default,MSCOnBoot=default,
        DFUOnBoot=default,UploadMode=default,CPUFreq=240,FlashMode=qio,FlashSize=16M,
        PartitionScheme=custom,DebugLevel=error,PSRAM=opi,LoopCore=1,EventsCore=1,EraseFlash=all,
        JTAGAdapter=default,ZigbeeMode=default
  Sketch: firmware/Gotek_JC3248/Gotek_JC3248.ino  (uses ../shared/ and the sketch-local partitions.csv)
  Output: Gotek_JC3248.ino.merged.bin, then DOOM1.WAD written into it at offset 0x810000.

Using it
  Put CRACKTRO=666 in CONFIG.TXT, boot, tap the top-left corner during the cracktro.
